# Jump to Hyperspace v2 ⭐️ (mousedown/touchstart)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/RmZLXp](https://codepen.io/jh3y/pen/RmZLXp).

A second go at creating the jump to hyperspace star field 🤓

Used the opportunity to try out tweening canvas values with Greensock 💪

Enjoy!